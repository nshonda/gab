public interface OlaMundoInterface extends java.rmi.Remote {
	public void ola (String nome, String texto) 
		throws java.rmi.RemoteException;
}
